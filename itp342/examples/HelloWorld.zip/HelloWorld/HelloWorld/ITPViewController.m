//
//  ITPViewController.m
//  HelloWorld
//
//  Created by ITP Instructor on 1/17/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "ITPViewController.h"

@interface ITPViewController ()

// variables
@property (weak, nonatomic) IBOutlet UILabel *helloLabel;

@end

@implementation ITPViewController
@synthesize helloLabel;

- (IBAction)buttonTouched:(id)sender {
    NSString *msg = @"Hello World!";
    self.helloLabel.text = msg;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setHelloLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
