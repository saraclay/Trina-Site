Friend Picker sample

Demonstrates how to use a FBFriendPickerViewController in the Facebook SDK for iOS.

Using the Sample
Install the Facebook SDK for iOS.
Launch the FriendPickerSample project using Xcode from the <Facebook SDK>/samples/FriendPickerSample directory.
