//
//  BIDHeaderCell.h
//  DialogViewer
//

#import "BIDContentCell.h"

@interface BIDHeaderCell : BIDContentCell

@end
