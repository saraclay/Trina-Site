//
//  ITPTimer.h
//  Timer
//
//  Created by Trina Gregory on 2/7/13.
//  Copyright (c) 2013 ITP. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ITPTimer : NSObject

// public members
@property (strong, nonatomic, readonly) NSDate* initialTime;

// public methods
- (NSTimeInterval) elapsedTime;

@end
