//
//  main.m
//  Timer
//
//  Created by ITP Instructor on 2/7/13.
//  Copyright (c) 2013 ITP. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ITPAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ITPAppDelegate class]));
    }
}
