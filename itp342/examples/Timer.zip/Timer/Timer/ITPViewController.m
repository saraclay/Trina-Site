//
//  ITPViewController.m
//  Timer
//
//  Created by ITP Instructor on 2/7/13.
//  Copyright (c) 2013 ITP. All rights reserved.
//

#import "ITPViewController.h"
#import "ITPTimer.h"

@interface ITPViewController ()
@property (weak, nonatomic) IBOutlet UILabel *beginTime;
@property (weak, nonatomic) IBOutlet UILabel *elapsedTime;
@property (strong, nonatomic) ITPTimer* viewTimer;

@end

@implementation ITPViewController

- (IBAction)getTime:(id)sender {
    self.elapsedTime.text = [NSString stringWithFormat:@"%F", [self.viewTimer elapsedTime] ];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.viewTimer = [[ITPTimer alloc] init];
    self.beginTime.text = [NSString stringWithFormat:@"%@", self.viewTimer.initialTime];

	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
