//
//  ITPAppDelegate.h
//  Timer
//
//  Created by ITP Instructor on 2/7/13.
//  Copyright (c) 2013 ITP. All rights reserved.
//

#import <UIKit/UIKit.h>

//#import "ITPTimer.h"

// Forward Declaration
@class ITPTimer;

@interface ITPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ITPTimer* appTimer;

@end
