//
//  ITPTimer.m
//  Timer
//
//  Created by ITP Instructor on 2/7/13.
//  Copyright (c) 2013 ITP. All rights reserved.
//

#import "ITPTimer.h"

@interface ITPTimer ()
@property (strong, nonatomic, readwrite) NSDate* initialTime;
@end

@implementation ITPTimer

// use id or instancetype as the return type
// id is a typeless, generic object
// instancetype is the current class or any subclass
- (instancetype)init
{
    self = [super init];
    if (self) {
        // in init, Apple recommends using instance variable directly
        _initialTime = [[NSDate alloc] init];
    }
    return self;
}

- (NSTimeInterval) elapsedTime {
    NSDate* now = [[NSDate alloc] init];
    NSTimeInterval diffTime = [now timeIntervalSinceDate:self.initialTime];
    return diffTime;
}

@end
