//
//  ITPViewController.h
//  Timer
//
//  Created by ITP Instructor on 2/7/13.
//  Copyright (c) 2013 ITP. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ITPTimer;

@interface ITPViewController : UIViewController



@end
