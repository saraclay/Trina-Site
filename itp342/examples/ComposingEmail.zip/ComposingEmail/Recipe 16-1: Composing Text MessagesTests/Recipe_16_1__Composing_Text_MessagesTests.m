//
//  Recipe_16_1__Composing_Text_MessagesTests.m
//  Recipe 16-1: Composing Text MessagesTests
//
//  Created by joseph hoffman on 9/5/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Recipe_16_1__Composing_Text_MessagesTests : XCTestCase

@end

@implementation Recipe_16_1__Composing_Text_MessagesTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
