//
//  BIDViewController.h
//  Sections
//
//  Created by JN on 9/9/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController
    <UITableViewDataSource, UITableViewDelegate, UISearchDisplayDelegate>

@end
