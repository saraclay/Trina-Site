//
//  Word.m
//  Recipe 15-3 Using Core Data
//
//  Created by joseph hoffman on 9/3/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import "Word.h"
#import "Vocabulary.h"


@implementation Word

@dynamic word;
@dynamic translation;
@dynamic vocabulary;

@end
