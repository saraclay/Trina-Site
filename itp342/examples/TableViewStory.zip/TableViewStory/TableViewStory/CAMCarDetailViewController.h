//
//  CAMCarDetailViewController.h
//  TableViewStory
//
//  Created by Mr. Computer on 12/1/13.
//  Copyright (c) 2013 ITP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CAMCarDetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *makeLabel;
@property (weak, nonatomic) IBOutlet UILabel *modelLabel;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property (strong, nonatomic) NSArray *carDetailModel;

@end
