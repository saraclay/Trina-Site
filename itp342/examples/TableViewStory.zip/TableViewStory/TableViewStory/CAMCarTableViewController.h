//
//  CAMCarTableViewController.h
//  TableViewStory
//
//  Created by Mr. Computer on 12/1/13.
//  Copyright (c) 2013 ITP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CAMCarTableViewController : UITableViewController

@property (nonatomic, strong) NSArray *carImages;
@property (nonatomic, strong) NSArray *carMakes;
@property (nonatomic, strong) NSArray *carModels;

@end
