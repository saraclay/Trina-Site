//
//  AppDelegate.h
//  Recipe 11-4: Detecting Features
//
//  Created by joseph hoffman on 9/12/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
