//
//  _4_2_Fetching_Calendar_EventsTests.m
//  14-2 Fetching Calendar EventsTests
//
//  Created by joseph hoffman on 8/30/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _4_2_Fetching_Calendar_EventsTests : XCTestCase

@end

@implementation _4_2_Fetching_Calendar_EventsTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
