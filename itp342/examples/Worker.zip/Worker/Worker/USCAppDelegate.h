//
//  USCAppDelegate.h
//  Worker
//
//  Created by Trina Admin on 4/16/13.
//  Copyright (c) 2013 iOS Class. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface USCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
