//
//  main.m
//  Worker
//
//  Created by Trina Admin on 4/16/13.
//  Copyright (c) 2013 iOS Class. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "USCAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([USCAppDelegate class]));
    }
}
