//
//  USCViewController.h
//  Worker
//
//  Created by Trina Admin on 4/16/13.
//  Copyright (c) 2013 iOS Class. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface USCViewController : UIViewController

@end
