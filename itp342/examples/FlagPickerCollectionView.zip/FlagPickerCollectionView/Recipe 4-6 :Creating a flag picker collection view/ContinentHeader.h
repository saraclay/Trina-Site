//
//  ContinentHeader.h
//  Recipe 4-6 :Creating a flag picker collection view
//
//  Created by joseph hoffman on 7/15/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContinentHeader : UICollectionReusableView

@property (strong, nonatomic) UILabel *label;

@end
