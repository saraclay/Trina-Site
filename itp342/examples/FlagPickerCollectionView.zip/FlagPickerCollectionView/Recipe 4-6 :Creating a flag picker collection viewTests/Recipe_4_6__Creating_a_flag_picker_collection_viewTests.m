//
//  Recipe_4_6__Creating_a_flag_picker_collection_viewTests.m
//  Recipe 4-6 :Creating a flag picker collection viewTests
//
//  Created by joseph hoffman on 7/13/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Recipe_4_6__Creating_a_flag_picker_collection_viewTests : XCTestCase

@end

@implementation Recipe_4_6__Creating_a_flag_picker_collection_viewTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
