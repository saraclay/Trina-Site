//
//  BIDViewController.h
//  Camera
//
//  Created by JN on 2014-1-16.
//  Copyright (c) 2014 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDViewController : UIViewController

@end
