//
//  main.m
//  WhereAmI
//
//  Created by JN on 2014-1-10.
//  Copyright (c) 2014 apress. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BIDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BIDAppDelegate class]));
    }
}
