//
//  Recipe_7_1__Marking_Locations_wiht_PinsTests.m
//  Recipe 7-1: Marking Locations wiht PinsTests
//
//  Created by joseph hoffman on 8/10/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Recipe_7_1__Marking_Locations_wiht_PinsTests : XCTestCase

@end

@implementation Recipe_7_1__Marking_Locations_wiht_PinsTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
