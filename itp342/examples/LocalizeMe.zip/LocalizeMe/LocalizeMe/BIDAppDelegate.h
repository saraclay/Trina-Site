//
//  BIDAppDelegate.h
//  LocalizeMe
//
//  Created by JN on 2013-11-19.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
