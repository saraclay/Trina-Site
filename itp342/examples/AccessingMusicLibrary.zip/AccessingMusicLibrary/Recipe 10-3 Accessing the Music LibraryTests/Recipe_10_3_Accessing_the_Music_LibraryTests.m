//
//  Recipe_10_3_Accessing_the_Music_LibraryTests.m
//  Recipe 10-3 Accessing the Music LibraryTests
//
//  Created by joseph hoffman on 8/26/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Recipe_10_3_Accessing_the_Music_LibraryTests : XCTestCase

@end

@implementation Recipe_10_3_Accessing_the_Music_LibraryTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
