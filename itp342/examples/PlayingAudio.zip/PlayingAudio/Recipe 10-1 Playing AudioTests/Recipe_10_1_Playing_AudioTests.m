//
//  Recipe_10_1_Playing_AudioTests.m
//  Recipe 10-1 Playing AudioTests
//
//  Created by joseph hoffman on 8/26/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Recipe_10_1_Playing_AudioTests : XCTestCase

@end

@implementation Recipe_10_1_Playing_AudioTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
