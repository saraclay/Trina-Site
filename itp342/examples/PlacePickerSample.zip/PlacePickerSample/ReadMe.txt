PlacePickerSample

Demonstrates how to use the FBPlacePickerViewController provided with
the Facebook SDK for iOS.

Using the Sample
Install the Facebook SDK for iOS.
Launch the PlacePickerSample project using Xcode from the
<Facebook SDK>/samples/PlacePickerSample directory.
