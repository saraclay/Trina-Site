Session Login sample

Demonstrates how to use the FBSession object to login to Facebook and manage access tokens.

Using the Sample
Install the Facebook SDK for iOS.
Launch the SessionLoginSample project using Xcode from the
<Facebook SDK>/samples/SessionLoginSample directory.
