//
//  Recipe_15_4_Storing_Key_Value_Data_in_iCloudTests.m
//  Recipe 15-4 Storing Key-Value Data in iCloudTests
//
//  Created by joseph hoffman on 9/4/13.
//  Copyright (c) 2013 NSCookbook. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Recipe_15_4_Storing_Key_Value_Data_in_iCloudTests : XCTestCase

@end

@implementation Recipe_15_4_Storing_Key_Value_Data_in_iCloudTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
